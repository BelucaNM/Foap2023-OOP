-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-07-2024 a las 23:55:01
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `prova`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pisos`
--

CREATE TABLE `pisos` (
  `idPis` int(5) NOT NULL,
  `uidpis` varchar(30) NOT NULL,
  `tipus` tinyint(1) NOT NULL,
  `numHabitacions` int(2) NOT NULL,
  `numLavabos` int(2) NOT NULL,
  `users_uid` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pisos`
--

INSERT INTO `pisos` (`idPis`, `uidpis`, `tipus`, `numHabitacions`, `numLavabos`, `users_uid`) VALUES
(10, 'Piso2', 2, 3, 2, 'admin');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `users_id` int(11) NOT NULL,
  `users_uid` tinytext NOT NULL,
  `users_pwd` longtext NOT NULL,
  `users_email` tinytext NOT NULL,
  `cuentaActiva` tinyint(1) NOT NULL,
  `token` varchar(45) NOT NULL,
  `deadLine` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`users_id`, `users_uid`, `users_pwd`, `users_email`, `cuentaActiva`, `token`, `deadLine`) VALUES
(4, 'admin', '$2y$10$UbIv78Jhjw/PapEvmmilte9A/XS8D.3eNuElAzp/vApckdAq3N4QO', 'beluca.navarrina@gmail.com', 0, '', '2024-07-18 22:50:14'),
(5, 'profe', '$2y$10$qpafwrUkTUbnbYTxFmGGgeX2oWEvCoG1SsP3fIPX1BeY7PM2RknDC', 'isabel.navarrina@gmail.com', 0, '', '2024-07-18 21:50:56'),
(6, 'isabel', '$2y$10$3Sn9OtwGrWeM2oGzz6I97uR9W91zga.y/NngtxA4.t47iUQXB81oa', 'jesus@gmail.com', 0, '', '2024-07-18 22:12:35');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pisos`
--
ALTER TABLE `pisos`
  ADD PRIMARY KEY (`idPis`),
  ADD UNIQUE KEY `uidpis` (`uidpis`),
  ADD KEY `fk_pisos_users_idx` (`users_uid`(255));

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`users_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pisos`
--
ALTER TABLE `pisos`
  MODIFY `idPis` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `users_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
